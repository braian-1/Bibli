import { products } from "./products.js";
import { addToCart, clearCart } from "./cart.js";

document.addEventListener("DOMContentLoaded", () => {
  const productContainer = document.getElementById("products");

  products.forEach(product => {
    const card = document.createElement("div");
    card.classList.add("card");

    card.innerHTML = `
      <img src="${product.image}" alt="${product.name}" />
      <h3>${product.name}</h3>
      <p>$${product.price}</p>
      <button>Agregar al carrito</button>
    `;

    const btn = card.querySelector("button");
    btn.addEventListener("click", () => addToCart(product));

    productContainer.appendChild(card);
  });

  document.getElementById("toggleCart").addEventListener("click", () => {
    document.getElementById("cart").classList.toggle("hidden");
  });

  document.getElementById("clearCart").addEventListener("click", clearCart);
});

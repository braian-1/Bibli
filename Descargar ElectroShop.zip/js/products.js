export const products = [
  {
    id: 1,
    name: "Auriculares Bluetooth",
    price: 29.99,
    image: "https://via.placeholder.com/300x200?text=Auriculares"
  },
  {
    id: 2,
    name: "Teclado Mecánico RGB",
    price: 59.99,
    image: "https://via.placeholder.com/300x200?text=Teclado"
  },
  {
    id: 3,
    name: "Mouse Gamer",
    price: 19.99,
    image: "https://via.placeholder.com/300x200?text=Mouse"
  },
  {
    id: 4,
    name: "Pantalla LED 24''",
    price: 129.99,
    image: "https://via.placeholder.com/300x200?text=Pantalla"
  },
  {
    id: 5,
    name: "Laptop 14'' Ryzen 5",
    price: 499.99,
    image: "https://via.placeholder.com/300x200?text=Laptop"
  }
];

# SPA Gestión de Cursos

Instrucciones para ejecutar la aplicación con json-server.